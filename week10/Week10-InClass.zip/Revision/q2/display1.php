<?php

  require_once "Restaurant.php";

  $new_rest = new Restaurant ("Fat Cow", "$$$$$", "https://www.fatcow.com.sg/");
  
  echo "Restaurant is : "  ;
  echo "<br>";
  echo "Expensive : " . ;
  echo "<br>";
  $url = $new_rest->getURL();
  echo "URL is : " . ;

?>
