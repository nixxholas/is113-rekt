<?php

    class Furniture {
        // define my properties
      
        const Workmanship = 5;
        const GST = 0.07;

        // Constructor
        public function __construct($type, $cost) {
      
      
      
        }

        public function getCost(){
      
      
      
        }

        public function withGSTCost(){
      
      
      
        }
    }
?>
