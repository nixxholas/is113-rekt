<?php

    // complete this 
    require_once "Furniture.php";

    $table = new Furniture("table", 100);
    $chair = new Furniture("chair",35);

    // complete the codes
    echo "Table costs : " . ;
    echo "<br>";
    echo "Table costs : " . ;
    echo "<br>";
    echo "Chair costs : " . ;
    echo "<br>";
    echo "Chair costs : " . ;
    echo "<br>";
 
    // total cost of 1 table and 4 chairs.
    $total_amount = ;

    // add workmanship to the total cost  
    $total_amount +=  ;

    echo "Total amount is : " . $total_amount;

?>