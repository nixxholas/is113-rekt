<?php

    class ShoppingList{

        private $shopping_list;  // an indexed array of item Objects
        private $month;


        public function __construct($shopping_list, $month){
            $this->shopping_list = $shopping_list;
            $this->month = $month;
        }

        // Return the Shopping List 
        public function getShoppingList(){
      
      
      
        }

        // add an Item Object to the shopping list
        public function addItem($item){
      
      
        }

        // remove the Item Object which has $name = $item_name
        public function removeItem($item_name){

      
      
      
        }


    }



?>