<!DOCTYPE html>
<html>
    <body>
        
        <?php

            // Display all the items in books table

            // Step 1 : Connect to database
            

            // Step 2: Prepare PDO statement object 
            
            // Step 3: Specify the return data format
            
            // Step 4: Prepare the SQL statement
            //         which include replace the placeholder with variables

            // Step 5: Send the query to the server
            
            // Step 6: Process the data - retrieve result row by row
            

            /// Step  7 : free up resources
            
            
        ?>

    </body>
</html>


