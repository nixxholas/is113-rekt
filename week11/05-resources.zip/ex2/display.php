<!DOCTYPE html>
<html>
    <body>
        <table border='1'>
            <tr> 
                <th>Name</th> 
                <th>Gender</th> 
                <th>Age</th> 
            </tr>
            <?php   
                
                    # Step 1: Connect to the database
                  
                    # Step 2: Prepare PDO statement object 
                    
                    # Step 3: Specify the return data format
                  

                    # Step 4: Prepare the SQL statement
                    //         which include replace the placeholder with variables

                    # Step 5: Send the query to the server
                    
                    # Step 6: Process the data - retrieve result row by row
                    

                    # Step  7 : free up resources
                    
                    




                
                
            ?>
        </table>
    </body> 
</html>