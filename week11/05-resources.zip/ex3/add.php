<?php
    # Retrieve name, gender, age information passed from add.html
    $name = $_GET["name"];
    $gender = $_GET["gender"];
    $age = $_GET["age"];
   

        # Step 1: Connect to database
    
   
        # Step 2: prepare stmt object
   
        # Step 3: no records back from the database - no need FETCH
        //$statement->setFetchMode(PDO::FETCH_ASSOC);
            
        # Step 4: replace the placeholder with variables


        # Step 5: send query to database

        

        # Step 6: process the data 
        
        // Step  7 : free up resources
    




        
    }







?>