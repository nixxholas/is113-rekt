<?php
    require_once "autoload.php";
    $name = $_GET["name"];
    $gender = $_GET["gender"];
    $age = $_GET["age"];
    







    


?>