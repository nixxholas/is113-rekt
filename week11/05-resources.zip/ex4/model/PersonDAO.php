<?php
    require_once "autoload.php";

    class PersonDAO{
        function retrieveAll(){
            




        }

        function add($person) {
            
            



            
        }
    }
?>