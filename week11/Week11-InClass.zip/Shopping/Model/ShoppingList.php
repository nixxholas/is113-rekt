<?php

    class ShoppingList{

        private $month;
    
        public function __construct($month){
            $this->month = $month;
        }

        public function getMonth(){
            return $this->month;
        }

        // Return the Shopping List 
        public function getShoppingList(){
            //return $this->shopping_list;

        
        
        }

        // add an Item Object to the shopping list
        public function addItem($item){
            // $this->shopping_list[] = $item;
        
        
        }

        // remove the Item Object which has $name = $item_name
        public function removeItem($item_name){

           // for($i=0; $i<count($this->shopping_list); $i++){
           //     if ($this->shopping_list[$i]->getName() == $item_name){
           //         unset( $this->shopping_list[$i] );
           //     }
           // }
           
        
        
        
        
        
        
        
        
        }


    }



?>