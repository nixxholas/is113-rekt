<?php

require_once 'common.php';



?>
<html>
<body>

    <form action='delete.php' method='POST'>

    

    </form>

    <hr>
    Click <a href='display.php'>here</a> to return to Main Page

</body>
</html>