<?php

require_once 'common.php';

$id = '';
// How do you retrieve 'id' passed to edit.php?
// GET? POST?

// PostDAO object?

?>
<html>
<body>

    <form action='update.php' method='POST'>

    

    </form>

    <hr>
    Click <a href='display.php'>here</a> to return to Main Page

</body>
</html>