<?php

class Cat {
    private $name;
    private $age;
    private $gender;
    private $status;

    public function __construct($name, $age, $gender, $status) {
        // YOUR CODE GOES HERE
    }

    public function getName() {
        // YOUR CODE GOES HERE
    }

    public function getAge() {
        // YOUR CODE GOES HERE
    }

    public function getGender() {
        // YOUR CODE GOES HERE
    }

    public function getStatus() {
        // YOUR CODE GOES HERE
    }
}

?>