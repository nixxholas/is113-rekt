<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
</head> 
<body>
	
	<h1>[Club Name]: Add members </h1>
	<p> Back to club </p>
	Name [text field]<br/>
			
	Search

	<p class='highlight'>
		Can't add member to inactive club!
	</p>

	<h1>Search results</h1>
	<p class='highlight'>No result found.</p>

	1. Member's name<br/>
	2. [checkbox] Non-member's name<br/>
	
					
	Add members

	<?php
	include 'footer.php';
	?>

</body>
</html>
