<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
</head> 
<body>

	<table>
	<tr>
		<th>Name</th>
		<th>Is Active?</th>
	</tr>
	<tr>
		<td>
			Name
		</td>
		<td>
			Active or Inactive
		</td>
	</tr>
	</table>
</body>
</html>
