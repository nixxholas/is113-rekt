<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
</head> 
<body>
	
	<p class='highlight'>
		Empty name
		Saved!
		Ben Yong, Donny Wong removed!
		No member selected
	</p>
	
	<h1>Club's details</h1>
	
	<table>
	<tr>
		<th>Name</th>
		<td>
			[text field]
		</td>
	</tr>
	<tr>
		<th>Is active?</th>
		<td>
			[checkbox]
		</td>
	</tr>
	</table>

	
	Save
	
	
	<h1>Club's Members</h1>

	[checkbox] member's name; click on name should tick the checkbox<br/>
	[checkbox] member's name; click on name should tick the checkbox<br/>
	Remove selected members' />

	<p>No member.</p>
	
	<p>
		Add members >> 
	</p>

	<?php
	include 'footer.php';
	?>
	
</body>
</html>
