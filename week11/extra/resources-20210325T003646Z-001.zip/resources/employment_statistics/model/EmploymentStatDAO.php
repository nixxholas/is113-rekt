<?php
    class EmploymentStatDAO{

        // Get all records
        public function retrieveAll(){
           // add code here
        }

        public function searchByUniversity($university){
            // Add code to search records of a given university
        }

        
        public function add($employmentstat) {
            // Add code to insert a new employmentstat into employmentstat table in database 
        }

       
        public function update($id, $rate, $salary) {
           // Add code to update employment rate and salary of a record 
           // in employmentstat table in database, given the id of an existing record
        }

       
        public function delete($id) {
            // Add code to delete a record from employmentstat table in database, 
            // given the id of an existing record
        }
    }
?>