

<html>
<head>
	<title>Product Search by Price Range</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<h1>Product Search by Price Range</h1>
	
	<!-- form here -->
	Min price<br/>
	Max price<br/>
	<!-- submit button -->	
	
	
		<table>
		<tr>
			<th> S/N </th>
			<th> Product </th>
			<th> Category </th>
			<th> Quantity </th>
			<th> Price </th>
		</tr>
	
		<tr>
			<td> S/N </td>
			<td> Product </td>
			<td> Category </td>
			<td style='color:red;'> Quantity < 10 </td>
			<td> Price </td>
		</tr>

		<tr>
			<td> S/N </td>
			<td> Product </td>
			<td> Category </td>
			<td style='color:orange;'> Quantity < 20 </td>
			<td> Price </td>
		</tr>

		<tr>
			<td> S/N </td>
			<td> Product </td>
			<td> Category </td>
			<td style='color:black;'> Quantity </td>
			<td> Price </td>
		</tr>

		
		</table>
	</body>
</html>
