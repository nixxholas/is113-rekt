<html><body>
    <form method="post" action="page2.php">
        Name: <input type="text" name="name"/>
        <input type="submit" value="Next"/>
    </form>
</body></html>
