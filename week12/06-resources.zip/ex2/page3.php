<html>
    <body>
    <!-- add your code here -->
    <form method="post" action="summary.php">
        Hobby: <input type="text" name="hobby"/>
        <?php
            
                // YOUR CODE GOES HERE



        ?>
        <input type="submit" value="Next"/>
    </form>
</body></html>
