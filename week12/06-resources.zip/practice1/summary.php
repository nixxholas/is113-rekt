<?php
    echo "Name: " . $_POST["name"];
    echo "<br>";
    echo "Age: " . $_POST["age"];
?>
