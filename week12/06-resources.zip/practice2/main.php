<html>
  <body>
    <a href="view_object.php?src=a.jpg&width=500">
    View Object
    </a>
  </body>
</html>
