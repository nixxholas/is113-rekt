<?php
    session_start();
    echo "Name: " . $_SESSION["name"];
    echo "<br>";
    echo "Age: " . $_POST["age"];
?>
