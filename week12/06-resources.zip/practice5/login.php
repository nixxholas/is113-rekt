<!DOCTYPE html>
<html>
    <body>
        <h1>Login</h1>
        <form method="post" action="process_login.php">
            Username <input type="text" name="username"/>
            <br/>
            Password <input type="password" name="password"/>
            <br/>
            <input type="submit" value="Login"/>
        </form>
    </body>
</html>
