<!DOCTYPE html>
<html>
    <body>
        <h1>Register</h1>
        <form method="post" action="process_register.php">
            Username <input type="text" name="username"/>
            <br/>
            Password <input type="password" name="password"/>
            <br/>
            <input type="submit" value="Register"/>
        </form>
    </body>
</html>