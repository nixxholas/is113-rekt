<html>
  <body>
    <a href='another.php'>Go to another page</a>

    <a href='another.php?=another.php?secret=&submitbtn=Send'>Go another page </a>

  
  </body>
</html>
