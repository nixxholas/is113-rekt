<html>
  <body>
    <form action='another.php'>
        Secret: <input type="text" name="secret">
		<input type="submit" name="submitbtn" value="Send" >
	 </form>
  </body>
</html>
