<?php

  echo "<h3> This is second.php </h3>";

  echo "<h1> Welcome FIRST.PHP</h1>";
    
  header("location: http://www.google.com");
  //exit;
  
  header("Location: second.php");
  
  
 
 ?>