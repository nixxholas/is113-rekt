<?php

    echo "<h3> This is fourth.php </h3>";

    echo "<h1> Welcome FOURTH.PHP</h1>";


?>