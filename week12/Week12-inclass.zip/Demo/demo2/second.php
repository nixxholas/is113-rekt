<?php

    echo "<h3> This is second.php </h3>";

    echo "<h1> Welcome SECOND.PHP</h1>";

    header("Location: fourth.php");
  

?>