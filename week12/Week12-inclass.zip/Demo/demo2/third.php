<?php

    echo "<h3> This is thrid.php </h3>";

    echo "<h1> Welcome THIRD.PHP</h1>";
  


?>