<?php

    # check what session variables are still running

    session_start();
    var_dump($_SESSION);


?>