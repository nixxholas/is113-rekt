<?php

$pwd = "abc";

$hashed = password_hash($pwd, PASSWORD_DEFAULT);
var_dump($hashed);

$hashed = password_hash($pwd, PASSWORD_DEFAULT);
var_dump($hashed);

$hashed = password_hash($pwd, PASSWORD_DEFAULT);
var_dump($hashed);


?>