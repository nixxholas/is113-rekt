<?php
    
    // Complete the following function 
    // Check the expected output given on the slides
    function print_triangle($height){

        // Using a for loop
        for ($i=1; $i<=$height;$i++){
            
            for ($j=1;$j<=$i;$j++){
                echo "*";
            }

            echo "<br>";
        }
        

         // Using a while loop
         $p=1;
         while ($p <= $height){
             $q=0;
             while($q<$p){
                 echo "*";
                 $q = $q + 1;
             }
             echo "<br/>";
             $p = $p + 1;
         }

        
    }

?>
<!DOCTYPE html>
<html>
<body>
    <?php
        // In real-life, the following will be retrieved from a form
        $height = 6; // height of the triangle
        
        echo "Height: $height <br/>";

        print_triangle($height);

    ?>
</body>
</html>