<!-- This is showing the whole building block of HTML with PHP -->

<?php 
	// write the php codes in this block   

    echo "Hello Week 3 ... <br>";


?>
<!DOCTYPE html>
<html>
    <!– header block -->
    <head> 	
        
        <title> My Week 3 Schedule </title>

        <?php 
            /* write your codes here more codes */ 

        
	    ?>
    </head>
    <body>

        <ol>
            <li> Do homework </li>
            <li> Play games </li>
        </ol>

        <?php 
            # php codes could be here
            
            $task = ["do work", "cook"];
           /* echo "<ol>
                    <li> Do homework </li>
                    <li> Play games </li>
                  </ol>";*/

	    ?>
    </body>
</html>