<?php

    /* Demonstration of concaternation of strings */
    /* Use of " and ' */

    $name = "Cinderella";
    $pets = "dogs";

    // I want to print out Cinderella has dogs.

    echo "$name has $pets <br>";

    echo '$name has $pets <br>';

    echo "<hr>";

    // concatenate the two strings

    echo $name . " has " . $pets . "<br>";

    echo $name . ' has ' . $pets . '<br>';
    

?>