<?php

    // if statements

    $money = 55;

    if ($money > 1000){
        echo "I are super rich <br>";
        echo "xxx";
    }
    elseif ($money > 500) {
        echo "I am a a bit rich <br>";
    }
    else {
        echo "I got no money. <br>";
    
    }

    $money = 500;
    if ($money > 1000)
        echo "wah!!!";
    echo "send me some";




?>