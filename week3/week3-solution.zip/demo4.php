<?php

    // show ==, !=, ===, !===

    // Test the following.
    /* Case 1 : $var1 = 1.0
               $var2 = "1.0"
    
       Case 2 : $var1 = 1.0
                $var2 = 1.0
    
       Case 3 : $var1 = "abc";
                $var2 = abc;
    */
    

    $var1 = 1.0;
    $var2 = "1.0";

    if ($var1 == $var2){
        echo " ==  : $var1 is equal to $var2";
    }else {
        echo "== : $var1 is not equal to $var2";
    }

    echo "<br/>";

    if ($var1 === $var2){
        echo " ===  : $var1 is equal to $var2";
    }else {
        echo "=== : $var1 is not equal to $var2";
    }


    echo "<hr>";

?>