<?php

    $course = "Web Application Development";
	$i=0; $totalA=0; $totalNA=0;
	
	// Enter missing code here
    for ($i=0; $i<strlen($course); $i++){
        if (($course[$i] == 'a') || ($course[$i] == 'A'))
            $totalA++;
        else {
            $totalNA++;
        }
    }

    //$totalA = substr_count(strtolower($course), 'a');
    //$totalNA = strlen($course) - $totalA;

	echo 'Total a chars : ' . 	$totalA . '<br/>';
	echo 'Total non-a chars : ' . 	$totalNA . '<br/>';



?>
