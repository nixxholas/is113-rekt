<?php 

$valid='False';
$passwd='dearOnaaaaaaaaaaa';// hardcoded string to simulate user input.

function isUpperCase($string){
	$n = preg_match('/[A-Z]/', $string);
 	return $n;
}

function isLowerCase($string){
	$n= preg_match('/[a-z]/', $string);
 	return $n;
}

function isDigit($string){
 	$n= preg_match('/[0-9]/', $string);
 	return $n;
}


if (strlen($passwd)>6 && strlen($passwd)<21){

	if(isUpperCase($passwd) && isLowerCase($passwd) && isDigit($passwd)){
		$valid='True';
	}
	else 
	{

		$valid='False';
	}
} 

echo "$valid";

 ?>