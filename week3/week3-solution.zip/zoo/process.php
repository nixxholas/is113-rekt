<?php

    // This is to show what is sent over from the baby.html
    var_dump($_GET);


    // Assign the values to variables    
    $babyName = $_GET["babyName"];  // E.g. BabyX
    $animal = $_GET["animal"];      // E.g. tiger
    $room = $_GET["room"];          // E.g. room1
    
    // This is to check if the variable the user has ticked on any 
    // of the checkboxes
    if (isset ($_GET["health"])){
        // user did tick on at least 1 box
        $health = $_GET["health"];
    }
    else {
        // user did not tick on any checkboxes
        $health = null;
    }
    

    // Let print out the details
    echo "<h3> Details of New Baby Animal </h3>";

    echo 'Baby Name: '. $babyName . '<br>';

    echo 'It is a: '. $animal . '<br>';


    // if all the health status checkboxes are not selected. Print 
    // Health Status : not good
    // if not print out in an unordered list

    //var_dump($health);

    echo "Health Status :  ";
    if ($health == null){
        echo "not good <br>";
    }
    else {
        $health_arr_len =count($health);
        echo "<ul>";

            for ($i=0; $i<$health_arr_len; $i++){
                echo "<li>" . $health[$i] . "</li>";
            }

        echo "</ul>";
    }


    
    // Print nursery room number
    // Print an extra message - 
    // If in room 1 -  *** Welcome to Room 1 *** 
    // If in room 2 -  ---- Happy Birthday ---- 
    // If in room 3 -  ++++++ Stay Cute !!!! +++++++ 
    echo 'It is in Nursery '. $room . '<br>';

    if ($room == "room1"){
        echo "<h3> *** Welcome to Room 1 *** </h3>";
    }
    else if ($room == "room2"){
        echo "<h1>---- Happy Birthday ---- </h1>";
    }
    else {
        echo "<h2> ++++++ Stay Cute !!!! +++++++ </h2>";
    }




?>
