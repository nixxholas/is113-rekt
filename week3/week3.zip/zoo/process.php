<?php

    /* Let's print the results */

    // display what is received from $_GET    
    

    // assign to variables
    
    
    // Can health field be empty ?
    


    // Get room details
    $room = $_GET["room"];

    // Let print out the details
    echo "<h3> Details of New Baby Animal </h3>";


    // if all the health status checkboxes are not selected. Print 
    // Health Status : not good
    // if not print out in an unordered list

    
    // Print nursery room number
    // Print an extra message - 
    // If in room 1 -  *** Welcome to Room 1 *** 
    // If in room 2 -  ---- Happy Birthday ---- 
    // If in room 3 -  ++++++ Stay Cute !!!! +++++++ 
    




?>
