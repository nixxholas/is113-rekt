<!Doctype html>
<html>
<head>
    <title>Array using PHP</title>
</head>

<body>

    <hr>
    <h3>Static Ordered List</h3>
    
    <ol>
        <li>apple</li>
        <li>orange</li>
        <li>pear</li>
    </ol>

    <hr>
    <h3>Dynamic Ordered List - Indexed Array</h3>

    <?php

        // Given this Indexed Array
        $fruits = [ 'apple', 'orange', 'pear' ];

        // Add more furits to the array
        

       
        //print out the list of fruits array
       


        
    ?>



    <hr>
    <h3>Static Un-Ordered List</h3>

    <ul>
        <li>Monday - Water Plants</li>
        <li>Tuesday - Study</li>
        <li>Wednesday - Day Dream</li>
    </ul>


    <hr>
    <h3>Dynamic Un-Ordered List - with Associative Array</h3>

    <?php

        // Given this Indexed Array
        $toDo = [
                    "Monday" => "Water Plants",
                    "Tuesday"    => "Study",
                    "Wednesday"   => "Day Dream"
                ];

        // Complete PHP Code below
    
        

    ?>

</body>
</html>