<!Doctype html>
<html>
    <head>
        <title>Array in PHP</title>
    </head>

    <body>
        <h3>Dynamic Ordered List - with Array</h3>
        
        <?php
             // Given this Indexed Array
            $zodiacs = ["Rat", "Ox", "Tiger", "Rabbit", "Dragon"];
   
            // Complete PHP Code below using for loop
          




            echo "<hr>";

            // Complete PHP Code below using foreach loop
            echo "<h4> Indexed Array - foreach loop </h4>";

            echo "<ol>";



            echo "</ol>";

            // Given this Associate Array
            $zodiacs_year = ["Rat" => 2008,
                             "Ox" => 2009, 
                             "Tiger" => 2010, 
                             "Rabbit" => 2011,
                             "Dragon" => 2012];

             
            // Complete PHP Code below

           




            
        ?>

</body>
</html>

