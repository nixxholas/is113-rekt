<!DOCTYPE html>
<html>
    <body>

        Topics you like:<br>
        <ul>

        <?php	
            // 1. Complete the codes below to print out the topics selected
            // 2. Include validation if needed

            

            
        ?>

        </ul>



</body>
</html>
