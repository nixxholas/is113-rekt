<!DOCTYPE html>
<html>
    <body>

        Topics you like:<br>
        <ul>

        <?php	
            // 1. Complete the codes below to print out the topics selected
            // 2. Include validation if needed

            //var_dump($_GET);
            
            if (isset($_GET["topics"])){
                $topics = $_GET["topics"];
                foreach ($topics as $item ){
                    echo "<li>" . $item . "</li>";
                }
            }
            else
                echo "No topics found.";
                
           //var_dump($topics);

            
        ?>

        </ul>



</body>
</html>
