<!--
    Name: Nicholas Chen Han Wei
    Email: hwchen.2020@sis.smu.edu.sg
-->
<html>
<body>
    <form method='post' action='q2-display.php'>
        <input type="checkbox" value="apple" name="fruit[]">Apple
        <input type="checkbox" value="orange" name="fruit[]">Orange
        <input type="checkbox" value="pear" name="fruit[]">Pear
        <br>
        <input type='submit'>
    </form>
</body>
</html>