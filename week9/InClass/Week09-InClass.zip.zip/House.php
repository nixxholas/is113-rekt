<?php
// /*
// INSTRUCTIONS
// ============
//    1. Create a Class with the following properties : type, no_of_bedroom, size, location, price
//
//    2. Create getter functions.
//
//    3. Create a setting function.
// 
//    4. Create a function to calculate monthly payment.
//
//    5. Create a function to calculate cost per the sq ft.
//

	class House {
      

    }
















?>