<?php

    // 0. Import the class we need
    require_once "House.php";


    // 1. These are the values
    $data = [ "HDB", 4, "1010", "Montreal Drive" ];


   /* 
   
   $data = [ "type" => "HDB",
            "no_of_bedroom" => 4,
            "size" => "1010",
            "location" => "Montreal Drive"
          ]; 
    */
  
    
    $new_house1 =  ;
    
    // 2. Part of the Display
    // Copy from 1a
   

    

?>