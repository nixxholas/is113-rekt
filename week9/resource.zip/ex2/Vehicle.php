<?php
    class Vehicle{
        private $plateNum;
        private $type;
        public function printInfo(){
            echo "A Vehicle";
        }
    }
?>