<?php
     require_once "Vehicle.php";
     
     # Modify the following code
     $v1 = null;
     $v2 = null;
     var_dump($v1);
     var_dump($v2);
?>