<?php
     require_once "Vehicle.php";
     echo '<h4>Original: </h4>';

     $v1 = new Vehicle("27","car");
     $v2 = new Vehicle("37","truck");
     
     echo "<br/>";
     
     echo "<br/>";

     echo '<h4>After calling setType of $v1 and $v2: </h4>';

     
     
     
     echo "<br/>";
     
     echo "<br/>";
?>