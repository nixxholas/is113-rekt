<?php

    // /*
    // INSTRUCTIONS
    // ============

    // 1. Load the Person class.
    

    // 2. Update the following line to create a new person ("Harry", 35);
    $harry = null;  
    
    // 3. Update the following line to create a new person ("Mary", 27);
    $mary = null;
    
	$another_mary = $mary;
    $harry = $mary;
    
    // 4. print the name of $harry object
    

    // 5. print the name of mary object
    

    // 6. set the name of $harry object to "Harry" 
   

    // 7. print the name of $harry object
   

    // 8. print the name of $mary object
   
?>
